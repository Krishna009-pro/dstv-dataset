DATA STORYTELLING & VISUALIZATION LAB – INDIVIDUAL DATASET BANK
Academic Year: 2026–27

CONTENTS
1. Individual_Datasets folder: 78 unique CSV datasets.
2. Student_Dataset_Assignment.xlsx: roll-number-wise allocation.
3. Every dataset contains 600 records and is suitable for:
   - Import and exploration
   - Data cleaning and preprocessing
   - Basic and advanced visualizations
   - EDA, trends, patterns and anomaly detection
   - KPI calculation
   - Power BI / Tableau dashboard
   - Data storytelling and visual narrative
   - Comparative analysis
   - Time-series and geographical mini projects

INTENTIONALLY INCLUDED DATA-QUALITY ISSUES
- Missing values
- Exact duplicate rows
- Inconsistent capitalization and trailing spaces
- Numerical outliers
- Mixed categorical and numerical variables
- Date, month, quarter, city, state, region, latitude and longitude fields

USAGE RULE
Each student should work only on the dataset allocated against their roll number.
Students may use the same assigned dataset for Practicals 1–10 and Mini Project 11/12/13.
